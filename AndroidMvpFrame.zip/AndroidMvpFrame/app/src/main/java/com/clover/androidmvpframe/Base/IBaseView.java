package com.clover.androidmvpframe.Base;

public interface IBaseView {
}
